package asteroids;

public interface SaveHandler {

    public void save();

    public void load();

}
